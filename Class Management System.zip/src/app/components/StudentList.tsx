import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, DollarSign, User, Phone, Mail } from "lucide-react";

interface Student {
  id: string;
  classId: string;
  name: string;
  email: string;
  phone: string;
  parentName: string;
  parentPhone: string;
  monthlyFee: number;
}

interface StudentListProps {
  classId: string;
  apiUrl: string;
  apiKey: string;
}

export function StudentList({ classId, apiUrl, apiKey }: StudentListProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showTuitionModal, setShowTuitionModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    parentName: "",
    parentPhone: "",
    monthlyFee: "",
  });

  useEffect(() => {
    fetchStudents();
  }, [classId]);

  const fetchStudents = async () => {
    try {
      const response = await fetch(`${apiUrl}/students?classId=${classId}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      const data = await response.json();
      setStudents(data.students || []);
    } catch (error) {
      console.error("Error fetching students:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`${apiUrl}/students`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          classId,
          ...formData,
          monthlyFee: parseFloat(formData.monthlyFee) || 0,
        }),
      });
      const data = await response.json();
      setStudents([...students, data.student]);
      setShowAddForm(false);
      setFormData({
        name: "",
        email: "",
        phone: "",
        parentName: "",
        parentPhone: "",
        monthlyFee: "",
      });
    } catch (error) {
      console.error("Error adding student:", error);
    }
  };

  const handleDelete = async (studentId: string) => {
    if (!confirm("Bạn có chắc muốn xóa học viên này?")) return;
    
    try {
      await fetch(`${apiUrl}/students/${studentId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      setStudents(students.filter(s => s.id !== studentId));
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

  const handleRecordTuition = async () => {
    if (!selectedStudent) return;
    
    const month = new Date().toISOString().slice(0, 7); // YYYY-MM
    try {
      await fetch(`${apiUrl}/tuition`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          studentId: selectedStudent.id,
          amount: selectedStudent.monthlyFee,
          month,
          status: "paid",
        }),
      });
      alert("Đã ghi nhận học phí!");
      setShowTuitionModal(false);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error recording tuition:", error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Đang tải...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">
          Danh sách học viên ({students.length})
        </h2>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Thêm học viên
        </button>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold mb-4">Thêm học viên mới</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Họ tên *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Số điện thoại
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tên phụ huynh
                </label>
                <input
                  type="text"
                  value={formData.parentName}
                  onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  SĐT phụ huynh
                </label>
                <input
                  type="tel"
                  value={formData.parentPhone}
                  onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Học phí hàng tháng (VNĐ)
                </label>
                <input
                  type="number"
                  value={formData.monthlyFee}
                  onChange={(e) => setFormData({ ...formData, monthlyFee: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Thêm
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                >
                  Hủy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tuition Modal */}
      {showTuitionModal && selectedStudent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4">Ghi nhận học phí</h3>
            <p className="text-gray-700 mb-4">
              Ghi nhận học phí tháng này cho <strong>{selectedStudent.name}</strong>?
            </p>
            <p className="text-2xl font-bold text-blue-600 mb-6">
              {selectedStudent.monthlyFee.toLocaleString('vi-VN')} VNĐ
            </p>
            <div className="flex gap-2">
              <button
                onClick={handleRecordTuition}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Xác nhận
              </button>
              <button
                onClick={() => {
                  setShowTuitionModal(false);
                  setSelectedStudent(null);
                }}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
              >
                Hủy
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Student List */}
      {students.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          Chưa có học viên nào. Thêm học viên đầu tiên!
        </div>
      ) : (
        <div className="grid gap-4">
          {students.map((student) => (
            <div
              key={student.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-4"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">{student.name}</h3>
                  <div className="space-y-1 text-sm text-gray-600">
                    {student.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        <span>{student.email}</span>
                      </div>
                    )}
                    {student.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4" />
                        <span>{student.phone}</span>
                      </div>
                    )}
                    {student.parentName && (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>PH: {student.parentName} - {student.parentPhone}</span>
                      </div>
                    )}
                    {student.monthlyFee > 0 && (
                      <div className="flex items-center gap-2 font-medium text-blue-600">
                        <DollarSign className="w-4 h-4" />
                        <span>{student.monthlyFee.toLocaleString('vi-VN')} VNĐ/tháng</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setSelectedStudent(student);
                      setShowTuitionModal(true);
                    }}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                    title="Ghi nhận học phí"
                  >
                    <DollarSign className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(student.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Xóa"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
