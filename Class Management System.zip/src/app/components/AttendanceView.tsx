import { useState, useEffect } from "react";
import { Check, X, Clock, Calendar } from "lucide-react";

interface Student {
  id: string;
  name: string;
}

interface AttendanceRecord {
  studentId: string;
  status: "present" | "absent" | "late";
}

interface AttendanceViewProps {
  classId: string;
  apiUrl: string;
  apiKey: string;
}

export function AttendanceView({ classId, apiUrl, apiKey }: AttendanceViewProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [attendance, setAttendance] = useState<Record<string, "present" | "absent" | "late">>({});
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetchStudents();
  }, [classId]);

  useEffect(() => {
    fetchAttendance();
  }, [selectedDate, classId]);

  const fetchStudents = async () => {
    try {
      const response = await fetch(`${apiUrl}/students?classId=${classId}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      const data = await response.json();
      setStudents(data.students || []);
      
      // Initialize attendance to all present
      const initial: Record<string, "present" | "absent" | "late"> = {};
      (data.students || []).forEach((student: Student) => {
        initial[student.id] = "present";
      });
      setAttendance(initial);
    } catch (error) {
      console.error("Error fetching students:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAttendance = async () => {
    try {
      const response = await fetch(
        `${apiUrl}/attendance?classId=${classId}&date=${selectedDate}`,
        {
          headers: { Authorization: `Bearer ${apiKey}` },
        }
      );
      const data = await response.json();
      
      if (data.records && data.records.length > 0) {
        const attendanceMap: Record<string, "present" | "absent" | "late"> = {};
        data.records.forEach((record: any) => {
          attendanceMap[record.studentId] = record.status;
        });
        setAttendance(attendanceMap);
      }
    } catch (error) {
      console.error("Error fetching attendance:", error);
    }
  };

  const handleStatusChange = (studentId: string, status: "present" | "absent" | "late") => {
    setAttendance({ ...attendance, [studentId]: status });
    setSaved(false);
  };

  const handleSave = async () => {
    try {
      const records = Object.entries(attendance).map(([studentId, status]) => ({
        studentId,
        status,
      }));

      await fetch(`${apiUrl}/attendance/batch`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          classId,
          date: selectedDate,
          records,
        }),
      });

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error("Error saving attendance:", error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Đang tải...</div>;
  }

  const presentCount = Object.values(attendance).filter(s => s === "present").length;
  const absentCount = Object.values(attendance).filter(s => s === "absent").length;
  const lateCount = Object.values(attendance).filter(s => s === "late").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-xl font-semibold text-gray-900">Điểm danh</h2>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-gray-500" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={handleSave}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              saved
                ? "bg-green-600 text-white"
                : "bg-blue-600 text-white hover:bg-blue-700"
            }`}
          >
            {saved ? "✓ Đã lưu" : "Lưu điểm danh"}
          </button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-green-700">
            <Check className="w-5 h-5" />
            <span className="font-medium">Có mặt</span>
          </div>
          <p className="text-2xl font-bold text-green-900 mt-2">{presentCount}</p>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-red-700">
            <X className="w-5 h-5" />
            <span className="font-medium">Vắng</span>
          </div>
          <p className="text-2xl font-bold text-red-900 mt-2">{absentCount}</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-yellow-700">
            <Clock className="w-5 h-5" />
            <span className="font-medium">Đi muộn</span>
          </div>
          <p className="text-2xl font-bold text-yellow-900 mt-2">{lateCount}</p>
        </div>
      </div>

      {/* Student List */}
      {students.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          Chưa có học viên nào trong lớp này.
        </div>
      ) : (
        <div className="space-y-3">
          {students.map((student) => (
            <div
              key={student.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-gray-900">{student.name}</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleStatusChange(student.id, "present")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      attendance[student.id] === "present"
                        ? "bg-green-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    <Check className="w-4 h-4 inline mr-1" />
                    Có mặt
                  </button>
                  <button
                    onClick={() => handleStatusChange(student.id, "late")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      attendance[student.id] === "late"
                        ? "bg-yellow-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    <Clock className="w-4 h-4 inline mr-1" />
                    Muộn
                  </button>
                  <button
                    onClick={() => handleStatusChange(student.id, "absent")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      attendance[student.id] === "absent"
                        ? "bg-red-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    <X className="w-4 h-4 inline mr-1" />
                    Vắng
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
