import { useState, useEffect } from "react";
import { Plus, BookMarked, Trash2 } from "lucide-react";

interface VocabWord {
  word: string;
  definition: string;
  example: string;
}

interface VocabList {
  id: string;
  classId: string;
  week: string;
  words: VocabWord[];
  createdAt: string;
}

interface VocabularyListProps {
  classId: string;
  apiUrl: string;
  apiKey: string;
}

export function VocabularyList({ classId, apiUrl, apiKey }: VocabularyListProps) {
  const [vocabLists, setVocabLists] = useState<VocabList[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [week, setWeek] = useState("");
  const [words, setWords] = useState<VocabWord[]>([
    { word: "", definition: "", example: "" },
  ]);

  useEffect(() => {
    fetchVocabulary();
  }, [classId]);

  const fetchVocabulary = async () => {
    try {
      const response = await fetch(`${apiUrl}/vocabulary?classId=${classId}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      const data = await response.json();
      setVocabLists(data.vocabulary || []);
    } catch (error) {
      console.error("Error fetching vocabulary:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddWord = () => {
    setWords([...words, { word: "", definition: "", example: "" }]);
  };

  const handleRemoveWord = (index: number) => {
    setWords(words.filter((_, i) => i !== index));
  };

  const handleWordChange = (index: number, field: keyof VocabWord, value: string) => {
    const updated = [...words];
    updated[index][field] = value;
    setWords(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validWords = words.filter(w => w.word.trim() !== "");
    
    if (validWords.length === 0) {
      alert("Vui lòng thêm ít nhất một từ vựng!");
      return;
    }

    try {
      const response = await fetch(`${apiUrl}/vocabulary`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          classId,
          week,
          words: validWords,
        }),
      });
      const data = await response.json();
      setVocabLists([data.vocabulary, ...vocabLists]);
      setShowAddForm(false);
      setWeek("");
      setWords([{ word: "", definition: "", example: "" }]);
    } catch (error) {
      console.error("Error adding vocabulary:", error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Đang tải...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">
          Từ vựng ({vocabLists.length} tuần)
        </h2>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Thêm từ vựng
        </button>
      </div>

      {/* Add Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full my-8">
            <h3 className="text-lg font-semibold mb-4">Thêm từ vựng mới</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tuần học *
                </label>
                <input
                  type="text"
                  required
                  value={week}
                  onChange={(e) => setWeek(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ví dụ: Week 1, Tuần 5"
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Danh sách từ vựng
                  </label>
                  <button
                    type="button"
                    onClick={handleAddWord}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    + Thêm từ
                  </button>
                </div>

                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {words.map((word, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <span className="text-sm font-medium text-gray-700">Từ #{index + 1}</span>
                        {words.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveWord(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={word.word}
                        onChange={(e) => handleWordChange(index, "word", e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Từ vựng (Word)"
                      />
                      <input
                        type="text"
                        value={word.definition}
                        onChange={(e) => handleWordChange(index, "definition", e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Nghĩa (Definition)"
                      />
                      <input
                        type="text"
                        value={word.example}
                        onChange={(e) => handleWordChange(index, "example", e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Ví dụ (Example)"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Lưu
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setWeek("");
                    setWords([{ word: "", definition: "", example: "" }]);
                  }}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                >
                  Hủy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Vocabulary Lists */}
      {vocabLists.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          Chưa có từ vựng nào. Thêm từ vựng đầu tiên!
        </div>
      ) : (
        <div className="space-y-6">
          {vocabLists.map((list) => (
            <div
              key={list.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6"
            >
              <div className="flex items-center gap-2 mb-4">
                <BookMarked className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900">{list.week}</h3>
                <span className="text-sm text-gray-500">
                  ({list.words.length} từ)
                </span>
              </div>

              <div className="grid gap-4">
                {list.words.map((word, index) => (
                  <div
                    key={index}
                    className="bg-gray-50 rounded-lg p-4 border border-gray-200"
                  >
                    <div className="font-medium text-blue-600 text-lg mb-1">
                      {word.word}
                    </div>
                    {word.definition && (
                      <div className="text-gray-700 mb-1">
                        <span className="font-medium">Nghĩa:</span> {word.definition}
                      </div>
                    )}
                    {word.example && (
                      <div className="text-gray-600 text-sm italic">
                        <span className="font-medium not-italic">Ví dụ:</span> {word.example}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
